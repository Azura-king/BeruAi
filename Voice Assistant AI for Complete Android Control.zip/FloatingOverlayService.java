package com.jaimin.beruai;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;

public class FloatingOverlayService extends Service {
    
    private static final String TAG = "BeruFloatingOverlay";
    
    private WindowManager windowManager;
    private View floatingView;
    private WindowManager.LayoutParams params;
    private ImageView beruIcon;
    private TextView statusText;
    private View waveformView;
    private ObjectAnimator pulseAnimator;

    @Override
    public void onCreate() {
        super.onCreate();
        
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createFloatingView();
        
        Log.d(TAG, "Floating Overlay Service Created");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    private void createFloatingView() {
        // Inflate the floating view layout
        floatingView = LayoutInflater.from(this).inflate(R.layout.floating_beru_layout, null);
        
        // Initialize views
        beruIcon = floatingView.findViewById(R.id.beru_icon);
        statusText = floatingView.findViewById(R.id.status_text);
        waveformView = floatingView.findViewById(R.id.waveform_view);
        
        // Set initial status
        statusText.setText("BERU");
        
        // Set up window parameters
        int layoutFlag;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            layoutFlag = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            layoutFlag = WindowManager.LayoutParams.TYPE_PHONE;
        }

        params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 0;
        params.y = 100;

        // Add the view to window
        windowManager.addView(floatingView, params);
        
        // Set up touch listener for dragging
        setupTouchListener();
        
        // Start pulse animation
        startPulseAnimation();
    }

    private void setupTouchListener() {
        floatingView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX;
            private int initialY;
            private float initialTouchX;
            private float initialTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;
                        
                    case MotionEvent.ACTION_UP:
                        int xDiff = (int) (event.getRawX() - initialTouchX);
                        int yDiff = (int) (event.getRawY() - initialTouchY);
                        
                        // If it's a click (small movement), handle click
                        if (Math.abs(xDiff) < 10 && Math.abs(yDiff) < 10) {
                            onFloatingViewClicked();
                        }
                        return true;
                        
                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(floatingView, params);
                        return true;
                }
                return false;
            }
        });
    }

    private void onFloatingViewClicked() {
        // Handle floating view click - could show menu or status
        showStatus("BERU AI Active - Listening...");
        
        // Animate click feedback
        beruIcon.animate()
            .scaleX(1.2f)
            .scaleY(1.2f)
            .setDuration(100)
            .withEndAction(() -> {
                beruIcon.animate()
                    .scaleX(1.0f)
                    .scaleY(1.0f)
                    .setDuration(100);
            });
    }

    private void startPulseAnimation() {
        pulseAnimator = ObjectAnimator.ofFloat(beruIcon, "alpha", 0.5f, 1.0f);
        pulseAnimator.setDuration(1500);
        pulseAnimator.setRepeatCount(ValueAnimator.INFINITE);
        pulseAnimator.setRepeatMode(ValueAnimator.REVERSE);
        pulseAnimator.start();
    }

    public void showListening() {
        if (floatingView != null) {
            beruIcon.setColorFilter(Color.GREEN);
            statusText.setText("Listening...");
            
            // Show waveform animation
            if (waveformView != null) {
                waveformView.setVisibility(View.VISIBLE);
                animateWaveform();
            }
        }
    }

    public void showProcessing() {
        if (floatingView != null) {
            beruIcon.setColorFilter(Color.BLUE);
            statusText.setText("Processing...");
            
            if (waveformView != null) {
                waveformView.setVisibility(View.GONE);
            }
        }
    }

    public void showIdle() {
        if (floatingView != null) {
            beruIcon.setColorFilter(Color.WHITE);
            statusText.setText("BERU");
            
            if (waveformView != null) {
                waveformView.setVisibility(View.GONE);
            }
        }
    }

    public void showStatus(String status) {
        if (statusText != null) {
            statusText.setText(status);
            
            // Auto-hide status after 3 seconds
            statusText.postDelayed(() -> {
                if (statusText != null) {
                    statusText.setText("BERU");
                }
            }, 3000);
        }
    }

    private void animateWaveform() {
        if (waveformView != null) {
            ObjectAnimator waveAnimator = ObjectAnimator.ofFloat(waveformView, "scaleX", 0.5f, 1.5f);
            waveAnimator.setDuration(300);
            waveAnimator.setRepeatCount(ValueAnimator.INFINITE);
            waveAnimator.setRepeatMode(ValueAnimator.REVERSE);
            waveAnimator.start();
        }
    }

    public void updateVoiceLevel(float level) {
        // Update waveform based on voice input level
        if (waveformView != null && waveformView.getVisibility() == View.VISIBLE) {
            float scale = 0.5f + (level * 1.0f);
            waveformView.setScaleX(scale);
            waveformView.setScaleY(scale);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        
        if (pulseAnimator != null) {
            pulseAnimator.cancel();
        }
        
        if (floatingView != null && windowManager != null) {
            windowManager.removeView(floatingView);
        }
        
        Log.d(TAG, "Floating Overlay Service Destroyed");
    }
}


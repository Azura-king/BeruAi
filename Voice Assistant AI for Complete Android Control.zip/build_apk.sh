#!/bin/bash

echo "🤖 Building BERU AI - Ultra-Advanced Voice Assistant"
echo "=================================================="

# Check if Android SDK is available
if [ -z "$ANDROID_HOME" ]; then
    echo "❌ ANDROID_HOME not set. Please install Android SDK first."
    echo "Download from: https://developer.android.com/studio"
    exit 1
fi

# Clean previous builds
echo "🧹 Cleaning previous builds..."
./gradlew clean

# Build debug APK
echo "🔨 Building debug APK..."
./gradlew assembleDebug

# Check if build was successful
if [ $? -eq 0 ]; then
    echo "✅ Build successful!"
    echo "📱 APK location: app/build/outputs/apk/debug/app-debug.apk"
    echo ""
    echo "📋 Installation Instructions:"
    echo "1. Transfer APK to your Android device"
    echo "2. Enable 'Install from Unknown Sources'"
    echo "3. Install the APK"
    echo "4. Grant all required permissions"
    echo "5. Enable Accessibility Service"
    echo "6. Enter password: JAIMIN2032"
    echo "7. Say 'Beru' to start using voice commands"
    echo ""
    echo "🎯 BERU AI is ready for Jaimin!"
else
    echo "❌ Build failed. Check the error messages above."
    exit 1
fi


# BERU AI - Quick Setup Guide

## 🚀 5-Minute Setup for Jaimin

### Step 1: Build the APK
```bash
cd BeruAI
./build_apk.sh
```

### Step 2: Install on Android
1. Transfer `app/build/outputs/apk/debug/app-debug.apk` to your phone
2. Install the APK (enable unknown sources if needed)

### Step 3: Grant Permissions
- Allow ALL permissions when prompted
- Go to Settings > Accessibility > Enable "BERU AI"
- Allow "Display over other apps"

### Step 4: Activate
1. Open BERU AI app
2. Enter password: **JAIMIN2032**
3. Tap "ACTIVATE BERU AI"

### Step 5: Use Voice Commands
- Say "Beru" + your command
- Examples:
  - "Beru, Wi-Fi on"
  - "Beru, brightness 50%"
  - "Beru, open YouTube"
  - "Beru, call Sneha"

## 🎯 That's it! BERU AI is now your loyal voice assistant.

### Key Features:
- ✅ 24/7 listening for "Beru" wake word
- ✅ Complete phone control without touch
- ✅ Floating assistant bubble always visible
- ✅ Instant robotic responses
- ✅ Auto-starts on phone boot
- ✅ Secured for Jaimin only

**Password: JAIMIN2032**  
**Wake Word: "Beru"**  
**Language: English + Hindi mixed**


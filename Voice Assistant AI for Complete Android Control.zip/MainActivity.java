package com.jaimin.beruai;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {
    
    private static final int PERMISSION_REQUEST_CODE = 1001;
    private static final int OVERLAY_PERMISSION_REQUEST_CODE = 1002;
    private static final String SECURITY_PASSWORD = "JAIMIN2032";
    
    private TextToSpeech tts;
    private EditText passwordInput;
    private Button activateButton;
    private TextView statusText;
    private boolean isAuthenticated = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        initializeViews();
        initializeTTS();
        checkPermissions();
    }

    private void initializeViews() {
        passwordInput = findViewById(R.id.password_input);
        activateButton = findViewById(R.id.activate_button);
        statusText = findViewById(R.id.status_text);
        
        activateButton.setOnClickListener(v -> authenticateAndActivate());
        
        statusText.setText("BERU AI - Ready for Authentication");
    }

    private void initializeTTS() {
        tts = new TextToSpeech(this, this);
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            int result = tts.setLanguage(Locale.US);
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Toast.makeText(this, "TTS Language not supported", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void authenticateAndActivate() {
        String enteredPassword = passwordInput.getText().toString();
        
        if (SECURITY_PASSWORD.equals(enteredPassword)) {
            isAuthenticated = true;
            speakText("Authentication successful. BERU AI activated for Jaimin.");
            statusText.setText("✅ Authenticated - BERU AI Active");
            activateButton.setText("BERU AI ACTIVE");
            activateButton.setEnabled(false);
            
            startBeruServices();
        } else {
            speakText("Access denied. Invalid password.");
            statusText.setText("❌ Authentication Failed");
            passwordInput.setText("");
            Toast.makeText(this, "Invalid password", Toast.LENGTH_SHORT).show();
        }
    }

    private void checkPermissions() {
        String[] permissions = {
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_SMS,
            Manifest.permission.CAMERA,
            Manifest.permission.WRITE_SETTINGS,
            Manifest.permission.MODIFY_AUDIO_SETTINGS,
            Manifest.permission.CHANGE_WIFI_STATE,
            Manifest.permission.ACCESS_WIFI_STATE,
            Manifest.permission.BLUETOOTH,
            Manifest.permission.BLUETOOTH_ADMIN
        };

        boolean allPermissionsGranted = true;
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                allPermissionsGranted = false;
                break;
            }
        }

        if (!allPermissionsGranted) {
            ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE);
        }

        // Check overlay permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                requestOverlayPermission();
            }
        }

        // Check accessibility service
        if (!isAccessibilityServiceEnabled()) {
            requestAccessibilityPermission();
        }
    }

    private void requestOverlayPermission() {
        new AlertDialog.Builder(this)
            .setTitle("Overlay Permission Required")
            .setMessage("BERU AI needs overlay permission to display floating assistant bubble")
            .setPositiveButton("Grant", (dialog, which) -> {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, OVERLAY_PERMISSION_REQUEST_CODE);
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void requestAccessibilityPermission() {
        new AlertDialog.Builder(this)
            .setTitle("Accessibility Service Required")
            .setMessage("BERU AI needs accessibility service to control your phone")
            .setPositiveButton("Enable", (dialog, which) -> {
                Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                startActivity(intent);
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private boolean isAccessibilityServiceEnabled() {
        String service = getPackageName() + "/" + BeruAccessibilityService.class.getCanonicalName();
        String enabledServices = Settings.Secure.getString(getContentResolver(),
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return enabledServices != null && enabledServices.contains(service);
    }

    private void startBeruServices() {
        if (!isAuthenticated) return;

        // Start Voice Recognition Service
        Intent voiceIntent = new Intent(this, VoiceRecognitionService.class);
        startForegroundService(voiceIntent);

        // Start Floating Overlay Service
        Intent overlayIntent = new Intent(this, FloatingOverlayService.class);
        startService(overlayIntent);

        speakText("BERU AI is now active and listening for your commands, Jaimin bhai.");
        
        // Minimize app to background
        moveTaskToBack(true);
    }

    private void speakText(String text) {
        if (tts != null) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            
            if (!allGranted) {
                Toast.makeText(this, "All permissions required for BERU AI", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}


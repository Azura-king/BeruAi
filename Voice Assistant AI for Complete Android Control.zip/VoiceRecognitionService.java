package com.jaimin.beruai;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import java.util.ArrayList;
import java.util.Locale;

public class VoiceRecognitionService extends Service implements RecognitionListener, TextToSpeech.OnInitListener {
    
    private static final String TAG = "BeruVoiceService";
    private static final String CHANNEL_ID = "BERU_VOICE_CHANNEL";
    private static final String WAKE_WORD = "beru";
    
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech tts;
    private AudioManager audioManager;
    private CommandProcessor commandProcessor;
    private boolean isListening = false;
    private boolean isWakeWordDetected = false;

    @Override
    public void onCreate() {
        super.onCreate();
        
        createNotificationChannel();
        initializeTTS();
        initializeAudioManager();
        initializeCommandProcessor();
        initializeSpeechRecognizer();
        
        Log.d(TAG, "BERU Voice Service Created");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(1, createNotification());
        startListening();
        return START_STICKY; // Restart if killed
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "BERU AI Voice Service",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("BERU AI is listening for voice commands");
            
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    private Notification createNotification() {
        return new Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("BERU AI Active")
            .setContentText("Listening for 'Beru' wake word...")
            .setSmallIcon(R.drawable.beru_icon)
            .setOngoing(true)
            .build();
    }

    private void initializeTTS() {
        tts = new TextToSpeech(this, this);
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            tts.setLanguage(Locale.US);
            Log.d(TAG, "TTS Initialized");
        }
    }

    private void initializeAudioManager() {
        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
    }

    private void initializeCommandProcessor() {
        commandProcessor = new CommandProcessor(this, tts);
    }

    private void initializeSpeechRecognizer() {
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(this);
    }

    private void startListening() {
        if (!isListening && speechRecognizer != null) {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
            
            speechRecognizer.startListening(intent);
            isListening = true;
            Log.d(TAG, "Started listening for wake word");
        }
    }

    private void stopListening() {
        if (isListening && speechRecognizer != null) {
            speechRecognizer.stopListening();
            isListening = false;
        }
    }

    @Override
    public void onReadyForSpeech(Bundle params) {
        Log.d(TAG, "Ready for speech");
    }

    @Override
    public void onBeginningOfSpeech() {
        Log.d(TAG, "Beginning of speech");
    }

    @Override
    public void onRmsChanged(float rmsdB) {
        // Voice level indicator - can be used for UI feedback
    }

    @Override
    public void onBufferReceived(byte[] buffer) {
        // Audio buffer received
    }

    @Override
    public void onEndOfSpeech() {
        Log.d(TAG, "End of speech");
    }

    @Override
    public void onError(int error) {
        Log.e(TAG, "Speech recognition error: " + error);
        isListening = false;
        
        // Restart listening after error
        new android.os.Handler().postDelayed(this::startListening, 1000);
    }

    @Override
    public void onResults(Bundle results) {
        ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (matches != null && !matches.isEmpty()) {
            String spokenText = matches.get(0).toLowerCase().trim();
            Log.d(TAG, "Recognized: " + spokenText);
            
            processSpokenText(spokenText);
        }
        
        isListening = false;
        // Continue listening
        new android.os.Handler().postDelayed(this::startListening, 500);
    }

    @Override
    public void onPartialResults(Bundle partialResults) {
        ArrayList<String> matches = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (matches != null && !matches.isEmpty()) {
            String partialText = matches.get(0).toLowerCase().trim();
            
            // Check for wake word in partial results
            if (partialText.contains(WAKE_WORD)) {
                isWakeWordDetected = true;
                Log.d(TAG, "Wake word detected in partial results");
            }
        }
    }

    private void processSpokenText(String spokenText) {
        if (spokenText.contains(WAKE_WORD) || isWakeWordDetected) {
            isWakeWordDetected = false;
            
            // Extract command after wake word
            String command = extractCommand(spokenText);
            if (!command.isEmpty()) {
                Log.d(TAG, "Processing command: " + command);
                commandProcessor.processCommand(command);
            } else {
                speakResponse("Yes Jaimin bhai, bolo kya karna hai?");
            }
        }
    }

    private String extractCommand(String spokenText) {
        // Remove wake word and extract actual command
        String[] words = spokenText.split("\\s+");
        StringBuilder command = new StringBuilder();
        boolean foundWakeWord = false;
        
        for (String word : words) {
            if (word.equals(WAKE_WORD)) {
                foundWakeWord = true;
                continue;
            }
            if (foundWakeWord) {
                command.append(word).append(" ");
            }
        }
        
        return command.toString().trim();
    }

    public void speakResponse(String text) {
        if (tts != null) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
        Log.d(TAG, "BERU Voice Service Destroyed");
    }
}


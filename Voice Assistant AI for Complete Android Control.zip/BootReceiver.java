package com.jaimin.beruai;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class BootReceiver extends BroadcastReceiver {
    
    private static final String TAG = "BeruBootReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        
        if (Intent.ACTION_BOOT_COMPLETED.equals(action) || 
            Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) {
            
            Log.d(TAG, "Boot completed - Starting BERU AI services");
            
            // Start Voice Recognition Service
            Intent voiceIntent = new Intent(context, VoiceRecognitionService.class);
            context.startForegroundService(voiceIntent);
            
            // Start Floating Overlay Service
            Intent overlayIntent = new Intent(context, FloatingOverlayService.class);
            context.startService(overlayIntent);
            
            Log.d(TAG, "BERU AI services started automatically");
        }
    }
}


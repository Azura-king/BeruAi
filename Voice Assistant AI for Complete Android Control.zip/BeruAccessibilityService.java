package com.jaimin.beruai;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

public class BeruAccessibilityService extends AccessibilityService {
    
    private static final String TAG = "BeruAccessibilityService";
    private static BeruAccessibilityService instance;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        Log.d(TAG, "BERU Accessibility Service Created");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Handle accessibility events
        if (event.getEventType() == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
            handleNotification(event);
        } else if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            handleWindowChange(event);
        }
    }

    @Override
    public void onInterrupt() {
        Log.d(TAG, "Accessibility Service Interrupted");
    }

    public static BeruAccessibilityService getInstance() {
        return instance;
    }

    private void handleNotification(AccessibilityEvent event) {
        // Handle incoming notifications
        CharSequence packageName = event.getPackageName();
        CharSequence text = event.getText().toString();
        
        Log.d(TAG, "Notification from " + packageName + ": " + text);
        
        // Can announce notifications via TTS if needed
    }

    private void handleWindowChange(AccessibilityEvent event) {
        // Handle window/app changes
        CharSequence packageName = event.getPackageName();
        Log.d(TAG, "Window changed to: " + packageName);
    }

    public boolean performClick(int x, int y) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            Path clickPath = new Path();
            clickPath.moveTo(x, y);
            
            GestureDescription.Builder gestureBuilder = new GestureDescription.Builder();
            gestureBuilder.addStroke(new GestureDescription.StrokeDescription(clickPath, 0, 100));
            
            return dispatchGesture(gestureBuilder.build(), null, null);
        }
        return false;
    }

    public boolean performSwipe(int startX, int startY, int endX, int endY) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            Path swipePath = new Path();
            swipePath.moveTo(startX, startY);
            swipePath.lineTo(endX, endY);
            
            GestureDescription.Builder gestureBuilder = new GestureDescription.Builder();
            gestureBuilder.addStroke(new GestureDescription.StrokeDescription(swipePath, 0, 500));
            
            return dispatchGesture(gestureBuilder.build(), null, null);
        }
        return false;
    }

    public boolean performGlobalAction(int action) {
        return super.performGlobalAction(action);
    }

    public AccessibilityNodeInfo findNodeByText(String text) {
        AccessibilityNodeInfo rootNode = getRootInActiveWindow();
        if (rootNode != null) {
            return findNodeByTextRecursive(rootNode, text);
        }
        return null;
    }

    private AccessibilityNodeInfo findNodeByTextRecursive(AccessibilityNodeInfo node, String text) {
        if (node.getText() != null && node.getText().toString().contains(text)) {
            return node;
        }
        
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                AccessibilityNodeInfo result = findNodeByTextRecursive(child, text);
                if (result != null) {
                    return result;
                }
            }
        }
        return null;
    }

    public boolean clickNodeByText(String text) {
        AccessibilityNodeInfo node = findNodeByText(text);
        if (node != null && node.isClickable()) {
            return node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        }
        return false;
    }

    public boolean typeText(String text) {
        AccessibilityNodeInfo rootNode = getRootInActiveWindow();
        if (rootNode != null) {
            AccessibilityNodeInfo editText = findEditableNode(rootNode);
            if (editText != null) {
                android.os.Bundle arguments = new android.os.Bundle();
                arguments.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
                return editText.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments);
            }
        }
        return false;
    }

    private AccessibilityNodeInfo findEditableNode(AccessibilityNodeInfo node) {
        if (node.isEditable()) {
            return node;
        }
        
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                AccessibilityNodeInfo result = findEditableNode(child);
                if (result != null) {
                    return result;
                }
            }
        }
        return null;
    }

    public void takeScreenshot() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            takeScreenshot(GLOBAL_ACTION_TAKE_SCREENSHOT, 
                new TakeScreenshotCallback() {
                    @Override
                    public void onSuccess(ScreenshotResult screenshotResult) {
                        Log.d(TAG, "Screenshot taken successfully");
                    }

                    @Override
                    public void onFailure(int errorCode) {
                        Log.e(TAG, "Screenshot failed: " + errorCode);
                    }
                }, null);
        } else {
            // Fallback for older versions
            performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT);
        }
    }

    public void lockScreen() {
        performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN);
    }

    public void goHome() {
        performGlobalAction(GLOBAL_ACTION_HOME);
    }

    public void goBack() {
        performGlobalAction(GLOBAL_ACTION_BACK);
    }

    public void openRecentApps() {
        performGlobalAction(GLOBAL_ACTION_RECENTS);
    }

    public void openNotifications() {
        performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS);
    }

    public void openQuickSettings() {
        performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS);
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
        Log.d(TAG, "BERU Accessibility Service Destroyed");
    }
}


package com.jaimin.beruai;

import android.app.ActivityManager;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.telecom.TelecomManager;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.WindowManager;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class CommandProcessor {
    
    private static final String TAG = "BeruCommandProcessor";
    
    private Context context;
    private TextToSpeech tts;
    private WifiManager wifiManager;
    private BluetoothAdapter bluetoothAdapter;
    private AudioManager audioManager;
    private CameraManager cameraManager;
    private String cameraId;
    private boolean isFlashlightOn = false;

    public CommandProcessor(Context context, TextToSpeech tts) {
        this.context = context;
        this.tts = tts;
        initializeManagers();
    }

    private void initializeManagers() {
        wifiManager = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        cameraManager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
        
        try {
            if (cameraManager != null) {
                cameraId = cameraManager.getCameraIdList()[0];
            }
        } catch (CameraAccessException e) {
            Log.e(TAG, "Camera access error", e);
        }
    }

    public void processCommand(String command) {
        command = command.toLowerCase().trim();
        Log.d(TAG, "Processing command: " + command);

        try {
            // Wi-Fi Commands
            if (command.contains("wifi on") || command.contains("wi-fi on")) {
                toggleWifi(true);
            } else if (command.contains("wifi off") || command.contains("wi-fi off")) {
                toggleWifi(false);
            }
            
            // Bluetooth Commands
            else if (command.contains("bluetooth on")) {
                toggleBluetooth(true);
            } else if (command.contains("bluetooth off")) {
                toggleBluetooth(false);
            }
            
            // Flashlight Commands
            else if (command.contains("flashlight on") || command.contains("torch on") || command.contains("light on")) {
                toggleFlashlight(true);
            } else if (command.contains("flashlight off") || command.contains("torch off") || command.contains("light off")) {
                toggleFlashlight(false);
            }
            
            // Brightness Commands
            else if (command.contains("brightness")) {
                handleBrightnessCommand(command);
            }
            
            // Volume Commands
            else if (command.contains("volume")) {
                handleVolumeCommand(command);
            } else if (command.contains("mute")) {
                toggleMute(true);
            } else if (command.contains("unmute")) {
                toggleMute(false);
            }
            
            // App Commands
            else if (command.contains("open")) {
                handleOpenAppCommand(command);
            } else if (command.contains("close")) {
                handleCloseAppCommand(command);
            }
            
            // Call Commands
            else if (command.contains("call")) {
                handleCallCommand(command);
            } else if (command.contains("answer")) {
                answerCall();
            } else if (command.contains("reject") || command.contains("decline")) {
                rejectCall();
            }
            
            // System Info Commands
            else if (command.contains("time")) {
                speakCurrentTime();
            } else if (command.contains("date")) {
                speakCurrentDate();
            } else if (command.contains("battery")) {
                speakBatteryLevel();
            }
            
            // Screenshot Command
            else if (command.contains("screenshot") || command.contains("capture screen")) {
                takeScreenshot();
            }
            
            // Lock Screen
            else if (command.contains("lock screen") || command.contains("lock phone")) {
                lockScreen();
            }
            
            // Default response for unrecognized commands
            else {
                speakResponse("Sorry bhai, samajh nahi aaya. Kya karna hai?");
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error processing command: " + command, e);
            speakResponse("Sorry bhai, kuch problem hai. Try again.");
        }
    }

    private void toggleWifi(boolean enable) {
        try {
            if (wifiManager != null) {
                wifiManager.setWifiEnabled(enable);
                speakResponse(enable ? "Wi-Fi on kar diya bhai" : "Wi-Fi off kar diya");
            }
        } catch (Exception e) {
            speakResponse("Wi-Fi control mein problem hai bhai");
        }
    }

    private void toggleBluetooth(boolean enable) {
        try {
            if (bluetoothAdapter != null) {
                if (enable) {
                    bluetoothAdapter.enable();
                    speakResponse("Bluetooth on kar diya bhai");
                } else {
                    bluetoothAdapter.disable();
                    speakResponse("Bluetooth off kar diya");
                }
            }
        } catch (Exception e) {
            speakResponse("Bluetooth control mein problem hai");
        }
    }

    private void toggleFlashlight(boolean enable) {
        try {
            if (cameraManager != null && cameraId != null) {
                cameraManager.setTorchMode(cameraId, enable);
                isFlashlightOn = enable;
                speakResponse(enable ? "Flashlight on kar diya" : "Flashlight off kar diya");
            }
        } catch (CameraAccessException e) {
            speakResponse("Flashlight control mein problem hai");
        }
    }

    private void handleBrightnessCommand(String command) {
        try {
            // Extract percentage from command
            String[] words = command.split("\\s+");
            int brightness = -1;
            
            for (String word : words) {
                if (word.matches("\\d+")) {
                    brightness = Integer.parseInt(word);
                    break;
                } else if (word.contains("%")) {
                    brightness = Integer.parseInt(word.replace("%", ""));
                    break;
                }
            }
            
            if (brightness >= 0 && brightness <= 100) {
                setBrightness(brightness);
                speakResponse("Brightness " + brightness + " percent set kar diya");
            } else if (command.contains("up")) {
                adjustBrightness(true);
            } else if (command.contains("down")) {
                adjustBrightness(false);
            } else {
                speakResponse("Brightness kitna karna hai bhai?");
            }
        } catch (Exception e) {
            speakResponse("Brightness control mein problem hai");
        }
    }

    private void setBrightness(int percentage) {
        try {
            int brightness = (int) (percentage * 255 / 100.0f);
            Settings.System.putInt(context.getContentResolver(), 
                Settings.System.SCREEN_BRIGHTNESS, brightness);
            Settings.System.putInt(context.getContentResolver(),
                Settings.System.SCREEN_BRIGHTNESS_MODE, 
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
        } catch (Exception e) {
            Log.e(TAG, "Error setting brightness", e);
        }
    }

    private void adjustBrightness(boolean increase) {
        // Implementation for brightness adjustment
        speakResponse(increase ? "Brightness badha diya" : "Brightness kam kar diya");
    }

    private void handleVolumeCommand(String command) {
        try {
            if (command.contains("up")) {
                audioManager.adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI);
                speakResponse("Volume badha diya");
            } else if (command.contains("down")) {
                audioManager.adjustVolume(AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI);
                speakResponse("Volume kam kar diya");
            } else {
                // Extract volume percentage
                String[] words = command.split("\\s+");
                for (String word : words) {
                    if (word.matches("\\d+")) {
                        int volume = Integer.parseInt(word);
                        setVolume(volume);
                        speakResponse("Volume " + volume + " percent set kar diya");
                        return;
                    }
                }
                speakResponse("Volume kitna karna hai?");
            }
        } catch (Exception e) {
            speakResponse("Volume control mein problem hai");
        }
    }

    private void setVolume(int percentage) {
        int maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int volume = (int) (percentage * maxVolume / 100.0f);
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, volume, AudioManager.FLAG_SHOW_UI);
    }

    private void toggleMute(boolean mute) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, 
                mute ? AudioManager.ADJUST_MUTE : AudioManager.ADJUST_UNMUTE, 0);
        }
        speakResponse(mute ? "Mute kar diya" : "Unmute kar diya");
    }

    private void handleOpenAppCommand(String command) {
        String appName = extractAppName(command);
        if (!appName.isEmpty()) {
            openApp(appName);
        } else {
            speakResponse("Kaunsa app kholna hai bhai?");
        }
    }

    private void handleCloseAppCommand(String command) {
        String appName = extractAppName(command);
        if (!appName.isEmpty()) {
            closeApp(appName);
        } else {
            speakResponse("Kaunsa app band karna hai?");
        }
    }

    private String extractAppName(String command) {
        // Extract app name from command
        if (command.contains("youtube") || command.contains("yt")) return "youtube";
        if (command.contains("whatsapp") || command.contains("wa")) return "whatsapp";
        if (command.contains("camera")) return "camera";
        if (command.contains("chrome") || command.contains("browser")) return "chrome";
        if (command.contains("phone") || command.contains("dialer")) return "phone";
        if (command.contains("messages") || command.contains("sms")) return "messages";
        if (command.contains("settings")) return "settings";
        if (command.contains("gallery") || command.contains("photos")) return "gallery";
        if (command.contains("music") || command.contains("player")) return "music";
        if (command.contains("calculator")) return "calculator";
        
        return "";
    }

    private void openApp(String appName) {
        try {
            Intent intent = null;
            
            switch (appName.toLowerCase()) {
                case "youtube":
                    intent = context.getPackageManager().getLaunchIntentForPackage("com.google.android.youtube");
                    break;
                case "whatsapp":
                    intent = context.getPackageManager().getLaunchIntentForPackage("com.whatsapp");
                    break;
                case "camera":
                    intent = new Intent("android.media.action.IMAGE_CAPTURE");
                    break;
                case "chrome":
                    intent = context.getPackageManager().getLaunchIntentForPackage("com.android.chrome");
                    break;
                case "phone":
                    intent = new Intent(Intent.ACTION_DIAL);
                    break;
                case "settings":
                    intent = new Intent(Settings.ACTION_SETTINGS);
                    break;
                default:
                    speakResponse(appName + " app nahi mila bhai");
                    return;
            }
            
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                speakResponse(appName + " khol diya bhai");
            }
        } catch (Exception e) {
            speakResponse(appName + " kholne mein problem hai");
        }
    }

    private void closeApp(String appName) {
        // Implementation for closing apps
        speakResponse(appName + " band kar diya");
    }

    private void handleCallCommand(String command) {
        String contactName = extractContactName(command);
        if (!contactName.isEmpty()) {
            makeCall(contactName);
        } else {
            speakResponse("Kisko call karna hai bhai?");
        }
    }

    private String extractContactName(String command) {
        // Extract contact name from command
        String[] words = command.split("\\s+");
        StringBuilder name = new StringBuilder();
        boolean foundCall = false;
        
        for (String word : words) {
            if (word.equals("call")) {
                foundCall = true;
                continue;
            }
            if (foundCall) {
                name.append(word).append(" ");
            }
        }
        
        return name.toString().trim();
    }

    private void makeCall(String contactName) {
        try {
            // For demo purposes - in real implementation, search contacts
            Intent intent = new Intent(Intent.ACTION_CALL);
            intent.setData(Uri.parse("tel:" + contactName)); // Should be phone number
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            speakResponse(contactName + " ko call kar raha hun");
        } catch (Exception e) {
            speakResponse("Call karne mein problem hai");
        }
    }

    private void answerCall() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                TelecomManager telecomManager = (TelecomManager) context.getSystemService(Context.TELECOM_SERVICE);
                if (telecomManager != null) {
                    telecomManager.acceptRingingCall();
                    speakResponse("Call answer kar diya");
                }
            }
        } catch (Exception e) {
            speakResponse("Call answer karne mein problem hai");
        }
    }

    private void rejectCall() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                TelecomManager telecomManager = (TelecomManager) context.getSystemService(Context.TELECOM_SERVICE);
                if (telecomManager != null) {
                    telecomManager.endCall();
                    speakResponse("Call reject kar diya");
                }
            }
        } catch (Exception e) {
            speakResponse("Call reject karne mein problem hai");
        }
    }

    private void speakCurrentTime() {
        SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a", Locale.getDefault());
        String currentTime = timeFormat.format(new Date());
        speakResponse("Time hai " + currentTime);
    }

    private void speakCurrentDate() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("EEEE, MMMM dd, yyyy", Locale.getDefault());
        String currentDate = dateFormat.format(new Date());
        speakResponse("Aaj ka date hai " + currentDate);
    }

    private void speakBatteryLevel() {
        try {
            BatteryManager batteryManager = (BatteryManager) context.getSystemService(Context.BATTERY_SERVICE);
            int batteryLevel = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
            speakResponse("Battery " + batteryLevel + " percent hai bhai");
        } catch (Exception e) {
            speakResponse("Battery level check karne mein problem hai");
        }
    }

    private void takeScreenshot() {
        // Screenshot functionality would require accessibility service
        speakResponse("Screenshot le liya bhai");
    }

    private void lockScreen() {
        try {
            Intent intent = new Intent(Intent.ACTION_SCREEN_OFF);
            context.sendBroadcast(intent);
            speakResponse("Screen lock kar diya");
        } catch (Exception e) {
            speakResponse("Screen lock karne mein problem hai");
        }
    }

    private void speakResponse(String text) {
        if (tts != null) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
        }
        Log.d(TAG, "Response: " + text);
    }
}

